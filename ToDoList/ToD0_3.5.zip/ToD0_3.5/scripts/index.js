if (!localStorage.user) {
  location.replace('/login.html')
};

window.addEventListener('load', function () {
  const userName = document.querySelector('.user-info p');
  const btnCerrar = document.querySelector('#closeApp');

  const deposito = JSON.parse(localStorage.getItem('user'));
  const token = deposito.jwt;
  console.log(token);

  //renderizamos el nombre de usuario
  userName.innerText = deposito.name;
  //escuchamos los click en cerrar sesion
  btnCerrar.addEventListener('click', function () {
    //limpio el localStorage
    localStorage.clear();
    //envio al usuario a loggearse
    location.replace('/login.html');
  })

  const form = document.forms[0];
  const nuevaTarea = document.querySelector('#descripcion-tarea');
  const urlTareas = 'https://ctd-todo-api.herokuapp.com/v1/tasks';
  const tareasPendientes = document.querySelector('.tareas-pendientes');
  const tareasTerminadas = document.querySelector('.tareas-terminadas');

  /* -------------------------------------------------------------------------- */
  /*                      solicitar tareas del usuario: GET                     */
  /* -------------------------------------------------------------------------- */

  function obtenerTareas(url) {

    const settings = {
      method: 'GET',
      headers: {
        'authorization': token
      }
    }

    fetch(url, settings)
      .then(response => response.json())
      .then(data => {
        //recibimos el array de tareas
        console.log(data)
        //mostramos en pantalla las tareas
        renderizarTareas(data);
      })
      .catch(error => console.log(error))

  }

  //ejecuto la peticion de las tareas
  obtenerTareas(urlTareas);


  /* -------------------------------------------------------------------------- */
  /*                        renderizar tareas en el HTML                        */
  /* -------------------------------------------------------------------------- */
  function renderizarTareas(listado) {
    //limpio los contenedores
    tareasTerminadas.innerHTML = "";
    tareasPendientes.innerHTML = "";

    //recorremos el listado para mostrar en pantalla
    listado.forEach(tarea => {
      //si está terminada va a la lista que le corresponde
      if (tarea.completed) {
        tareasTerminadas.innerHTML += `
        <li class="tarea">
          <div class="done"></div>
          <div class="descripcion">
            <i id="${tarea.id}" class="far fa-trash-alt iconos"></i>
            <p class="nombre">${tarea.description}</p>
            <p class="timestamp">${tarea.createdAt}</p>
          </div>
        </li>
        `
      } else {
        //agregamos en la lista las tareas pendientes
        tareasPendientes.innerHTML += `
        <li class="tarea">
          <div id="${tarea.id}" class="not-done"></div>
          <div class="descripcion">
            <p class="nombre">${tarea.description}</p>
            <p class="timestamp">${tarea.createdAt}</p>
          </div>
        </li>
        `
      }
    });

    //escuchar los clicks de actualizar
    const botonesCambiarEstado = document.querySelectorAll('.tareas-pendientes .not-done');
    
    botonesCambiarEstado.forEach(boton => {
        boton.addEventListener('click', function(evento){
          console.log(evento.target.id);
          //llamamos a actualizar tarea
          cambiarEstadoTerminado(evento.target.id)
        });
    });

     //escuchar los clicks de actualizar
     const botonesEliminar = document.querySelectorAll('.tareas-terminadas .iconos');
    
     botonesEliminar.forEach(boton => {
         boton.addEventListener('click', function(evento){
           console.log(evento.target.id);
           //llamamos a actualizar tarea
           eliminarTarea(evento.target.id)
         });
     });



  }



  /* -------------------------------------------------------------------------- */
  /*                           crear nueva tarea: POST                          */
  /* -------------------------------------------------------------------------- */

  //escuchamos el submit del fomulario para la carga de una nueva tarea
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    console.log("nueva tarea");

    const payload = {
      description: nuevaTarea.value,
      completed: false
    }

    const settings = {
      method: 'POST',
      headers: {
        'authorization': token,
        'content-type': 'application/json'
      },
      body: JSON.stringify(payload)
    }

    fetch(urlTareas, settings)
      .then(response => response.json())
      .then(data => {
        //recibimos el array de tareas
        console.log(data)
        //consulto nuevamente para actualizar la UI
        obtenerTareas(urlTareas);
      })
      .catch(error => console.log(error))



    form.reset();
  });





  /* -------------------------------------------------------------------------- */
  /*               cambiar el estado de la tarea a terminada: PUT               */
  /* -------------------------------------------------------------------------- */

  function cambiarEstadoTerminado(id) {

    const endpointActualizar = `${urlTareas}/${id}`

    const payload = {
      completed: true
    }

    const settings = {
      method: 'PUT',
      headers: {
        'authorization': token,
        'content-type': 'application/json'
      },
      body: JSON.stringify(payload)
    }

    fetch(endpointActualizar, settings)
      .then(response => response.json())
      .then(data => {
        //recibimos el array de tareas
        console.log(data)
        //consulto nuevamente para actualizar la UI
        obtenerTareas(urlTareas);
      })
      .catch(error => console.log(error))

  };





  /* -------------------------------------------------------------------------- */
  /*                         eliminar una tarea: DELETE                         */
  /* -------------------------------------------------------------------------- */
  function eliminarTarea(id) {
    const endpointEliminar = `${urlTareas}/${id}`

    const settings = {
      method: 'DELETE',
      headers: {
        'authorization': token,
      }
    }

    fetch(endpointEliminar, settings)
      .then(response => response.json())
      .then(data => {
        //recibimos el array de tareas
        console.log(data)
        //consulto nuevamente para actualizar la UI
        obtenerTareas(urlTareas);
      })
      .catch(error => console.log(error))
  }






});



//template de tarea
/* <li class="tarea">
      <div class="not-done"></div>
      <div class="descripcion">
        <p class="nombre">Mi hermosa tarea</p>
        <p class="timestamp">Creada: 19/04/20</p>
      </div>
    </li> */